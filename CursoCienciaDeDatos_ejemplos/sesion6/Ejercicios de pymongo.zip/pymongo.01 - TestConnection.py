import connection as net
#Llamamos connection para hacer uso del cliente, este ya estará configurado

db = net.client.test
#Generamos un test de comunicación con Atlas

print(db)
